n1 = float(input('digite um numero: '))
n2 = float(input('digite um numero: '))
n3 = float(input('digite um numero: '))
def sum(n1,n2,n3):
    soma = n1+n2+n3
    return soma
print(sum(n1,n2,n3))