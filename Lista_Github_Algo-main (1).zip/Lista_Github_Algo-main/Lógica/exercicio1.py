"""
Um homem precisa atravessar um rio com um barco que possui capacidade de transportar apenas ele e mais uma de suas três cargas, 
que são: um lobo, uma ovelha e um kilo de couve. 
Quais os passos que o homem deve fazer para conseguir atravessar o rio sem perder as suas cargas?
"""

#Resposta
"""
Primeira viagem: O homem leva a ovelha para o outro lado do rio.
Segunda viagem: Ele volta sozinho para o lado inicial.
Terceira viagem: O homem leva o lobo para o outro lado do rio.
Quarta viagem: Ele traz a ovelha de volta para o lado inicial.
Quinta viagem: O homem leva a couve para o outro lado do rio.
Sexta viagem: Ele volta sozinho para o lado inicial.
Sétima viagem: O homem leva a ovelha para o outro lado do rio.
"""
