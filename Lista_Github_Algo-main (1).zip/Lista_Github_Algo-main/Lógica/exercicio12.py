"""
Ao observar a sequência de números abaixo, descubra qual das opções completa a série.

102, 103, 105, 108, ??

109
114
106
111
112
"""

#Resposta: 112, visto que ele segue um padrão parecido com o último exercicio, porém aqui ele vai aumentando gradualmente
#primeiro ele soma +1, depois +2, depois +3 e assim por diante, até chegar no final, que é 112.



