"""
Uma pessoa lê um livro de 100 páginas em 6 dias. Em quantos dias essa pessoa lê um livro de 150 páginas?
"""

#Resposta: 9 dias, só realiar uma regra de 3 e obter o valor

regra = (150 * 6 )/100
print(regra)
