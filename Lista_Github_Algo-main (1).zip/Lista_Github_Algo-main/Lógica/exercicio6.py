"""
Na Nlogônia, as cédulas de dinheiro são de $1,00, $3,00, $9,00, $27,00, e $81,00. Num dado momento, 
um vendedor possui apenas cinco cédulas, uma de cada um dos valores das cédulas existentes na Nlogônia. 
Qual dos valores abaixo não é possível ser dado como troco por esse vendedor?
$40,00
$35,00
$31,00
$13,00
$4,00
"""

#Resposta: $35,00, porque ele não pode ser formado, só com as celulas possíveis