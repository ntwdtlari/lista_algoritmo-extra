"""
Maria tinha alguns biscoitos. Ela comeu dois e deu dois à irmã. Depois deu metade do que sobrou ao irmão. 
Se o irmão ficou com 5 biscoitos, 
quantos tinha Maria no início?
"""

#Conclusão
#Maria tinha 14 biscoitos, visto que ela tinha dado metade do que sobrou pro irmão dela
#então o numero de biscoitos que sobraram com Maria andes disso foi:
biscoito = 5 * 2 
print(biscoito)

#Porém antes disso ela comeu 2 e deu 2 para a sua irmã, então somamos + 4
total_biscoito = biscoito + 4
print(total_biscoito)
