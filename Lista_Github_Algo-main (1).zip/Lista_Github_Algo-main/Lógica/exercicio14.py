"""
Para A = V, B = V e C = F, qual o resultado da avaliação das seguintes expressões lógicas:

A or C and not B
(A or B) and (A and C)
"""

#Resposta: 
# A or C and not B → 𝑉(verdadeiro)
#(A or B) and (A and C) → 𝐹(falso)