

matriz =[
    [3,4,6,7],
    [5,4,7,9]
]
print(matriz)