
temp = float(input('Informe tempo viagem: '))
vel = float(input('Informe vel media: '))
dist = temp * vel
lt = dist/12
print("Velocidade média: ",  vel, "Tempo gasto: ",  temp, "Distancia: ", dist, "quantidade de litros: ", lt )