pot = float(input("fale watts: "))
m = float(input("fale em m: "))
c = float(input('fale em c: '))

dim = m * c

x = dim/pot
print(x)
