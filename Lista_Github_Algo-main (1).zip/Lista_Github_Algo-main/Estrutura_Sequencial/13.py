m = int(input('metros quadrados: '))
qtd = m/3
val = qtd * 80
print('quantidade de litros', {qtd}, "valor ", {val})
