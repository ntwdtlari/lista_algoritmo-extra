a = 10
b = 20
aux = 0

aux = a
a = b
b = aux
print(a,b)